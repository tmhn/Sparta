var TwitterFeed = require('./twitterFeed.jsx');


ReactDOM.render(
  <TwitterFeed />, 
  document.getElementById('container')
);